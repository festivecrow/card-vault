import { createClient } from '@supabase/supabase-js';

const url = import.meta.env.VITE_SUPABASE_URL;
const key = import.meta.env.VITE_SUPABASE_ANON_KEY;

export const configMissing = !url || !key;

export const supabase = configMissing
  ? null
  : createClient(url, key, { auth: { persistSession: true, autoRefreshToken: true } });
